<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "anonychat";
$con = mysqli_connect($servername, $username, $password, $dbname);
?>