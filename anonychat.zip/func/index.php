<?php
header("location: ../");
?>